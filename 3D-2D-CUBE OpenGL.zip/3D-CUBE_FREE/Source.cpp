#include<stdio.h>
#include <iostream>


// GLEW
//#define GLEW_STATIC
#include <GL/glew.h>

// GLFW
#include <GLFW/glfw3.h>
#include"vmath.h"
#include"Camera.h"
#include"Sphere.h"

#pragma comment(lib,"glfw3.lib")
#pragma comment(lib,"glew32.lib")
#pragma comment(lib,"Sphere.lib")

#define  HIGH 0.002f
#define  LOW 0.0001f
#define DELTA 0.0166666666666667f

float x, y = 0.0f;
float sphereX, sphereY = 0.0f;
float sphereZ = -5.0f;
bool firstMouse = true;
bool startCubeDraw = false;

bool startIncrementX = true;
bool startIncrementY = true;
bool isLighting = false;

using namespace vmath;
using namespace std;

FILE *gpfile = NULL;

Camera camera(vmath::vec3(0.0f, 0.0f, 4.0f));

enum
{
	AMC_ATTRIBUTES_POSITION = 0,
	AMC_ATTRIBUTES_COLOR,
	AMC_ATTRIBUTES_NORMAL,
	AMC_ATTRIBUTES_TEXCOORD0
};

// Window dimensions
const GLuint WIDTH = 600, HEIGHT = 600;


GLfloat lastX = WIDTH / 2.0;
GLfloat lastY = HEIGHT / 2.0;

//OpenGL variables
//Main cube
GLuint gShaderProgramObject;
GLuint gVertexShaderObject;
GLuint gFragmentShaderObject;

GLuint vao_cube_main;
GLuint vbo_cube_position;
GLuint vbo_cube_color;


//Small cube
GLuint gShaderProgramObject_CubeSmall;
GLuint gVertexShaderObject_CubeSmall;
GLuint gFragmentShaderObject_CubeSmall;

GLuint vao_cube_small;
GLuint vbo_cube_position_small;
GLuint vbo_cube_normals_small;

//Uniforms
GLuint mvpUniform;
mat4 perspectiveProjectionMatrix;

float angle_cube = 0.0f;


//sphere var
//vao vbo
//sphere var
float sphere_vertices[1146];
float sphere_normals[1146];
float sphere_textures[764];
unsigned short sphere_elements[2280];
GLsizei gNumVertices, gNumElements;

//light array
float lightAmbient[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
float lightDifuse[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
float lightSpecular[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

//material array
float materialAmbient[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
float materialDifuse[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
float materialSpecular[4] = { 1.0f, 0.0f, 0.0f, 1.0f };

float lightPosition[4] = { 100.0f, 100.0f, 0.0f, 1.0f };

float materialShininess = 50.0f;

GLuint gShaderProgramObject_Sphere;
GLuint gVertexShaderObject_Sphere;
GLuint gFragmentShaderObject_Sphere;

GLuint vao_sphere;
GLuint vbo_position_vbo;
GLuint vbo_normals_vbo;
GLuint vbo_texcoord_vbo;
GLuint vbo_element_vbo;


int width, height;



//OpenGL function declarations
void uninitialize();
void initialize();


//Callbacks
static void error_callback(int error, const char* description)
{
	fprintf(gpfile, "Error: %s\n", description);
	uninitialize();
}

void ScrollCallback(GLFWwindow *window, double xOffset, double yOffset)
{
	camera.ProcessMouseScrool(yOffset, xOffset);
}

void MouseCallback(GLFWwindow *window, double xPos, double yPos)
{
	if (firstMouse)
	{
		lastX = xPos;
		lastY = yPos;
		firstMouse = false;
	}

	GLfloat xOffset = xPos - lastX;
	GLfloat yOffset = lastY - yPos;  // Reversed since y-coordinates go from bottom to left

	lastX = xPos;
	lastY = yPos;

	camera.ProcessMouseMovements(xOffset, yOffset);
}

static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);

	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
	{
		startCubeDraw = true;
	}

	//Left right arrow
	if (key == GLFW_KEY_LEFT && action == GLFW_PRESS)
	{
		sphereX -= 0.05f;
	}
	if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS)
	{
		sphereX += 0.05f;
	}

	//Up down arrow
	if (key == GLFW_KEY_UP && action == GLFW_PRESS)
	{
		sphereY += 0.05f;
	}
	if (key == GLFW_KEY_DOWN && action == GLFW_PRESS)
	{
		sphereY -= 0.05f;
	}

	//Z
	if (key == GLFW_KEY_COMMA && action == GLFW_PRESS)
	{
		sphereZ -= 0.05f;
	}
	if (key == GLFW_KEY_PERIOD && action == GLFW_PRESS)
	{
		sphereZ += 0.05f;
	}
	if (key == GLFW_KEY_F && action == GLFW_PRESS)
	{
		//ToogleFullscreen();
	}

	if (key == GLFW_KEY_L && action == GLFW_PRESS)
	{
		isLighting = !isLighting;
	}

	 switch(key)
	{
		case GLFW_KEY_A:// A is pressed
			camera.ProcessKeyBoard(E_LEFT, DELTA);
			break;
		 case GLFW_KEY_D:// D is pressed
			camera.ProcessKeyBoard(E_RIGHT, DELTA);
			break;
		 case GLFW_KEY_W:// W is pressed
			camera.ProcessKeyBoard(E_FORWARD, DELTA);
			break;
		 case GLFW_KEY_S:// S is pressed
			camera.ProcessKeyBoard(E_BACKARD, DELTA);
			break;
	}
}

// The MAIN function, from here we start the application and run the game loop
int main()
{
	//Function declarations
	void display();
	void resize(int width, int height);
	void MouseCallback(GLFWwindow *window, double xPos, double yPos);
	void ScrollCallback(GLFWwindow *window, double xOffset, double yOffset);
	// Init GLFW
	glfwInit();
	
	// Set all the required options for GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

	
	
	// Create a GLFWwindow object that we can use for GLFW's functions
	GLFWwindow *window = glfwCreateWindow(WIDTH, HEIGHT, "Conflicting", NULL, NULL);

	//NULL check
	if (nullptr == window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();

		return EXIT_FAILURE;
	}

	

	glfwMakeContextCurrent(window);

	//SetCallbacks
	glfwSetErrorCallback(error_callback);
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, MouseCallback);
	glfwSetScrollCallback(window, ScrollCallback);
	// Set this to true so GLEW knows to use a modern approach to retrieving function pointers and extensions
	glewExperimental = GL_TRUE;
	// Initialize GLEW to setup the OpenGL Function pointers
	if (GLEW_OK != glewInit())
	{
		std::cout << "Failed to initialize GLEW" << std::endl;
		return EXIT_FAILURE;
	}

	if (fopen_s(&gpfile, "log.txt", "w") != 0)
	{
		cout << "Failed to open file" << std::endl;
		return EXIT_FAILURE;
	}
	else
	{
		fprintf(gpfile, "File Created..");
	}
	//Initialize openGL shaders 

	initialize();

	// Game loop
	while (!glfwWindowShouldClose(window))
	{
		// Check if any events have been activiated (key pressed, mouse moved etc.) and call corresponding response functions
		glfwPollEvents();

		int screenWidth, screenHeight;
		glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

		// Define the viewport dimensions
		//glViewport(0, 0, screenWidth, screenHeight);
		resize(screenWidth, screenHeight);

		// Render
		
		

		display();

		// Swap the screen buffers
		glfwSwapBuffers(window);
	}

	uninitialize();
	// Terminate GLFW, clearing any resources allocated by GLFW.
	glfwTerminate();

	return EXIT_SUCCESS;
}

//Uninitialize the all allocated resources
void uninitialize()
{
	if (gpfile)
	{
		fclose(gpfile);
	}
}

void resize(int width, int height)
{
	if (height == 0)
	{
		height = 1;
	}
	glViewport(0, 0, (GLsizei)width, (GLsizei)height);

	perspectiveProjectionMatrix =
		perspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);

}

//Initialize the shaders
void initialize()
{
	void compileShaderProgram(const GLchar *shaderCode, GLuint shaderObject);
	void checkShaderProgramLinkError(GLuint shaderProgramObject);
	void initSphere();
	

	gVertexShaderObject = glCreateShader(GL_VERTEX_SHADER);

	//write vertex shader code
	// 
	const GLchar* vertexShaderSourceCode =
		"#version 430 core" \
		"\n" \
		"in vec4 vPosition;" \
		"in vec3 vColor;" \
		
		"out vec3 out_color;" \
		"uniform mat4 u_m_matrix;" \
		"uniform mat4 u_v_matrix;" \
		"uniform mat4 u_p_matrix;" \
		"void main(void)" \
		"{" \
			"gl_Position = u_p_matrix * u_v_matrix * u_m_matrix * vPosition;" \
			"out_color = vColor;" \
		" } ";
	
	compileShaderProgram(vertexShaderSourceCode, gVertexShaderObject);

	//********************FRAGMENT SHADER*****************
	gFragmentShaderObject = glCreateShader(GL_FRAGMENT_SHADER);

	//write vertex shader code 
	// 
	const GLchar * fragmentShaderSourceCode =
		"#version 430 core" \
		"\n" \
		"in vec3  out_color;" \
		"out vec4 fragColor;" \
		"uniform float blend;" \
		"uniform vec3 color;" \
		"void main(void)" \
		"{" \
			"vec4 tempColor = vec4(0.5f, 0.5f, 0.5f, 1.0f);" \
			"tempColor.a = blend;" \
			"fragColor = tempColor;" \
		"}";

	//compile
	compileShaderProgram(fragmentShaderSourceCode, gFragmentShaderObject);
	//Create shader program object
	gShaderProgramObject = glCreateProgram();



	//Attach vertex,fragment shader program
	glAttachShader(gShaderProgramObject, gVertexShaderObject);
	glAttachShader(gShaderProgramObject, gFragmentShaderObject);


	//*** PRELINKING BINDING TO VERTEX ATTRIBUTES***
	glBindAttribLocation(gShaderProgramObject,
		AMC_ATTRIBUTES_POSITION,
		"vPosition");

	glBindAttribLocation(gShaderProgramObject,
						AMC_ATTRIBUTES_COLOR,
						"vColor");
	//link above shader program
	glLinkProgram(gShaderProgramObject);

	// ***ERROR CHECKING LINKING********
	
	checkShaderProgramLinkError(gShaderProgramObject);

	//Get Uniform Locations

	fprintf(gpfile, "Post link success!!\n");

	const GLfloat cube_vertices[] =
	{
		//TOP
		 1.0f,1.0f,-1.0f,
		 -1.0f,1.0f,-1.0f,
		 -1.0f,1.0f,1.0f,
		 1.0f,1.0f,1.0f,
		 //bottom

		  1.0f,-1.0f,-1.0f,
		  -1.0f,-1.0f,-1.0f,
		  -1.0f,-1.0f,1.0f,
		  1.0f, -1.0f, 1.0f,
		  ////Front

		   1.0f,1.0f,1.0f,
		   -1.0f,1.0f,1.0f,
		   -1.0f,-1.0f,1.0f,
		   1.0f,-1.0f,1.0f,
		   //back

			1.0f,1.0f,-1.0f,
			-1.0f,1.0f,-1.0f,
			-1.0f,-1.0f,-1.0f,
			1.0f,-1.0f,-1.0f,

			//Right

			 1.0f,1.0f,-1.0f,
			 1.0f,1.0f,1.0f,
			 1.0f,-1.0f,1.0f,
			 1.0f,-1.0f,-1.0f,

			 //left

			  -1.0f,1.0f,1.0f,
			  -1.0f,1.0f,-1.0f,
			  -1.0f,-1.0f,-1.0f,
			  -1.0f,-1.0f,1.0f
	};

	const GLfloat cube_color[] =
	{
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,

		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,

		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,

		1.0f, 1.0f, 0.0f,
		1.0f, 1.0f, 0.0f,
		1.0f, 1.0f, 0.0f,
		1.0f, 1.0f, 0.0f,

		1.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 1.0f,

		0.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f,
	};
	//Small cube
	const GLfloat cube_vertices2[] =
	{
		//TOP
		 0.1f,0.1f,-0.1f,
		 -0.1f,0.1f,-0.1f,
		 -0.1f,0.1f,0.1f,
		 0.1f,0.1f,0.1f,
		 //bottom

		  0.1f,-0.1f,-0.1f,
		  -0.1f,-0.1f,-0.1f,
		  -0.1f,-0.1f,0.1f,
		  0.1f, -0.1f, 0.1f,
		  ////Front

		   0.1f,0.1f,0.1f,
		   -0.1f,0.1f,0.1f,
		   -0.1f,-0.1f,0.1f,
		   0.1f,-0.1f,0.1f,
		   //back

			0.1f,0.1f,-0.1f,
			-0.1f,0.1f,-0.1f,
			-0.1f,-0.1f,-0.1f,
			0.1f,-0.1f,-0.1f,

			//Right

			 0.1f,0.1f,-0.1f,
			 0.1f,0.1f,0.1f,
			 0.1f,-0.1f,0.1f,
			 0.1f,-0.1f,-0.1f,

			 //left

			  -0.1f,0.1f,0.1f,
			  -0.1f,0.1f,-0.1f,
			  -0.1f,-0.1f,-0.1f,
			  -0.1f,-0.1f,0.1f
	};

	const GLfloat normal_vertices[] =
	{
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,

		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,

		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,

		0.0f, 0.0f,-1.0f,
		0.0f, 0.0f,-1.0f,
		0.0f, 0.0f,-1.0f,
		0.0f, 0.0f,-1.0f,

		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,

		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f
	};

	//////create vao for cube...
	//////START:
	glGenVertexArrays(1, &vao_cube_main);

	glBindVertexArray(vao_cube_main);

	glGenBuffers(1, &vbo_cube_position);	//vbo position attach cube

	glBindBuffer(GL_ARRAY_BUFFER,
		vbo_cube_position);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(cube_vertices),
		cube_vertices,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_POSITION,
							3,
							GL_FLOAT,
							GL_FALSE,
							0,
							NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);		//Unbind vbo position py

	//COLOR
	glGenBuffers(1, &vbo_cube_color);

	glBindBuffer(GL_ARRAY_BUFFER,
		vbo_cube_color);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(cube_color),
		cube_color,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_COLOR,
							3,
							GL_FLOAT,
							GL_FALSE,
							0,
							NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_COLOR);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	///////////////////////////////Small cube//////////////////////////////////////

	const GLchar* vertexShaderSourceCode1 =
		"#version 430 core" \
		"\n" \
		"in vec4 vPosition;" \
		"in vec3 vNormal;" \
		"uniform mat4 u_m_matrix;" \
		"uniform mat4 u_v_matrix;" \
		"uniform mat4 u_projection_matrix;" \
		"uniform int u_islkeypressed;" \
		"uniform vec3 u_ld;" \
		"uniform vec3 u_kd;" \
		"uniform vec4 u_light_position;" \
		"out vec3 difuse_color;" \
		"void main(void)" \
		"{" \
			"if(u_islkeypressed == 1)" \
			"{" \
				"vec4 eye_coordinates = (u_m_matrix*u_v_matrix) * vPosition;" \
				"mat3 normal_matrix = mat3(transpose(inverse(u_m_matrix*u_v_matrix)));" \
				"vec3 tnorm = normalize(normal_matrix * vNormal);" \
				"vec3 s = normalize(vec3(u_light_position - eye_coordinates));" \
				"difuse_color = u_ld * u_kd * dot(s, tnorm);" \
			"}" \
		"gl_Position =  u_projection_matrix *  u_v_matrix * u_m_matrix * vPosition;" \
		" } ";

	gVertexShaderObject_CubeSmall = glCreateShader(GL_VERTEX_SHADER);

	compileShaderProgram(vertexShaderSourceCode1, gVertexShaderObject_CubeSmall);

	//Fragment

	const GLchar * fragmentShaderSourceCode2 =
		"#version 430 core" \
		"\n" \
		"out vec4 fragColor;" \
		"in vec3 difuse_color;" \
		"uniform int u_islkeypressed;" \
		"void main(void)" \
		"{" \
			"if(u_islkeypressed == 1)" \
			"{" \
			"vec3 fColor = difuse_color * vec3(1.0f, 0.0f, 0.0f);" \
			"fragColor = vec4(fColor, 1.0f);" \
			"}" \
			"else" \
			"{" \
			"fragColor = vec4(0.0, 0.0, 1.0, 1.0f);" \
			"}" \
		"}";

	gFragmentShaderObject_CubeSmall = glCreateShader(GL_FRAGMENT_SHADER);

	compileShaderProgram(fragmentShaderSourceCode2, gFragmentShaderObject_CubeSmall);

	//create shader program
	gShaderProgramObject_CubeSmall = glCreateProgram();

	//Attach vertex,fragment shader program
	glAttachShader(gShaderProgramObject_CubeSmall, gVertexShaderObject_CubeSmall);
	glAttachShader(gShaderProgramObject_CubeSmall, gFragmentShaderObject_CubeSmall);

	glBindAttribLocation(gShaderProgramObject_CubeSmall,
							AMC_ATTRIBUTES_POSITION,
							"vPosition");

	glBindAttribLocation(gShaderProgramObject_CubeSmall,
							AMC_ATTRIBUTES_NORMAL,
							"vNormal");

	//link above shader program
	glLinkProgram(gShaderProgramObject_CubeSmall);

	// ***ERROR CHECKING LINKING********

	checkShaderProgramLinkError(gShaderProgramObject_CubeSmall);

	//VAO VBO
	
	glGenVertexArrays(1, &vao_cube_small);

	glBindVertexArray(vao_cube_small);

	glGenBuffers(1, &vbo_cube_position_small);	//vbo position attach cube

	glBindBuffer(GL_ARRAY_BUFFER, vbo_cube_position_small);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(cube_vertices2),
		cube_vertices2,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_POSITION,
							3,
							GL_FLOAT,
							GL_FALSE,
							0,
							NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	//normals
	glGenBuffers(1, &vbo_cube_normals_small);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_cube_normals_small);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(normal_vertices),
		normal_vertices,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_NORMAL,
		3,
		GL_FLOAT,
		GL_FALSE,
		0,
		NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_NORMAL);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glBindVertexArray(0);
	
	//////////////////////// INIT SPHERE //////////////////////

	initSphere();
	

	//END:


	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	//glEnable(GL_CULL_FACE);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);

	glClearDepth(1.0f);

	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	//loadTexture(&texture_pyramid, MAKEINTRESOURCE(IDBITMAP_STONE));

	//loadTexture(&texture_cube, MAKEINTRESOURCE(IDBITMAP_KUNDALI));

	perspectiveProjectionMatrix = mat4::identity();
}

//Function  where all rendering happens
void display()
{
	void drawCube();
	void update();
	void drawSphere();


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	//2nd cube

	if (startCubeDraw)
	{
		drawCube();
	}
	
	//Sphere start

	drawSphere();
	//Sphere end

	///main cube
	glUseProgram(gShaderProgramObject);

	/*glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);*/


	mat4 modelMatrix;
	mat4 viewMatrix;
	mat4 modelViewProjectionMatrix;
	mat4 rotationMatrix;

	modelMatrix = mat4::identity();
	viewMatrix = mat4::identity();

	modelViewProjectionMatrix = mat4::identity();
	rotationMatrix = mat4::identity();

	modelMatrix = translate(0.0f, 0.0f, -5.0f);

	/*rotationMatrix = rotate(45.0f, 0.0f, 0.0f, 1.0f);
	rotationMatrix = rotationMatrix * rotate(angle_cube, 0.0f, 1.0f, 0.0f);
	rotationMatrix = rotationMatrix * rotate(angle_cube, 1.0f, 0.0f, 0.0f);*/

	/*modelViewProjectionMatrix = perspectiveProjectionMatrix * modelViewMatrix;

	modelViewProjectionMatrix = modelViewProjectionMatrix  ;*/

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject, "u_m_matrix"),
												1,
												GL_FALSE,
												modelMatrix);

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject, "u_v_matrix"),
													1,
													GL_FALSE,
													camera.GetViewMatrix());

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject, "u_p_matrix"),
												1,
												GL_FALSE,
												perspectiveProjectionMatrix);

	/*glUniform3f(glGetUniformLocation(gShaderProgramObject, "color"),0.7f, 0.7f, 0.7f);*/

	glUniform1f(glGetUniformLocation(gShaderProgramObject, "blend"), 0.35f);


	//
	glBindVertexArray(vao_cube_main);

	glDrawArrays(GL_TRIANGLE_FAN,
		0,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		4,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		8,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		12,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		16,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		20,
		4);

	glBindVertexArray(0);


	glUseProgram(0);

	//END of the main cube
	
	update();
}

//Updating the positions 
void update()
{
	angle_cube += 0.002f;

	float Tx = 0.0001f;
	float Ty = 0.0001f;

	if (startIncrementX)
	{
		x += Tx;
	}
	else
	{
		x -= Tx;
	}

	if (x >= 0.85f)
	{
		//Generate random X Y
		Tx = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		//Ty = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		startIncrementX = false;

	}
	if (x <= -0.85f)
	{
		startIncrementX = true;
		//Generate random X Y
		Tx = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		//Ty = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
	}


	//Y
	if (startIncrementY)
	{
		y += Ty;
	}
	else
	{
		y -= Ty;
	}

	if (y >= 0.85f)
	{
		//Generate random X Y
		Ty = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		//Ty = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		startIncrementY = false;

	}
	if (y <= -0.85f)
	{
		startIncrementY = true;
		//Generate random X Y
		Tx = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
		//Ty = LOW + static_cast <float> (rand()) / (static_cast <float> (RAND_MAX / (HIGH - LOW)));
	}



}

//Drawing cube using this function
void drawCube()
{

	glUseProgram(gShaderProgramObject_CubeSmall);

	mat4 modelMatrix;
	mat4 viewMatrix;
	mat4 modelViewProjectionMatrix;
	mat4 rotationMatrix;
	mat4 mvMatrix;

	modelMatrix = mat4::identity();
	viewMatrix = mat4::identity();
	mvMatrix = mat4::identity();

	modelViewProjectionMatrix = mat4::identity();
	rotationMatrix = mat4::identity();


	modelMatrix = translate(x, y, -4.5f);
	
	rotationMatrix = rotate(angle_cube, 0.0f, 0.0f, 1.0f);
	rotationMatrix = rotationMatrix * rotate(angle_cube, 0.0f, 1.0f, 0.0f);
	rotationMatrix = rotationMatrix * rotate(angle_cube, 1.0f, 0.0f, 0.0f);


	//scaleMatrix = scale(0.5f, 0.5f, 0.5f);

	if (isLighting)
	{
		glUniform1i(glGetUniformLocation(gShaderProgramObject_CubeSmall,"u_islkeypressed"), 1);

		//LD
		glUniform3f(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_ld"), 1.0f, 1.0f, 1.0f);

		//KD
		glUniform3f(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_kd"), 0.5f, 0.5f, 0.5f);

		//LPOS
		glUniform4f(glGetUniformLocation(gShaderProgramObject_CubeSmall,"u_light_position"), 10.0f, 10.0f, 2.0f, 1.0f);

	}
	else
	{
		glUniform1i(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_islkeypressed"), 0);
	}

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_m_matrix"),
												1,
												GL_FALSE,
												modelMatrix);

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_v_matrix"),
													1,
													GL_FALSE,
													camera.GetViewMatrix());

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_CubeSmall, "u_projection_matrix"),
													1,
													GL_FALSE,
													perspectiveProjectionMatrix);

	
	

	//
	glBindVertexArray(vao_cube_small);

	glDrawArrays(GL_TRIANGLE_FAN,
		0,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		4,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		8,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		12,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		16,
		4);

	glDrawArrays(GL_TRIANGLE_FAN,
		20,
		4);

	glBindVertexArray(0);

	glUseProgram(0);
}

//Compiling the shader programs
void compileShaderProgram(const GLchar *shaderCode, GLuint shaderObject)
{
	glShaderSource(shaderObject,
		1,
		(GLchar **)&shaderCode,
		NULL);
	//compile vertex shader code
	glCompileShader(shaderObject);

	//compile vertex shader code
	glCompileShader(shaderObject);

	//Error checking
	GLint iShaderCompilationStatus = 0;
	GLint iInfoLength = 0;
	GLchar *szInfoLog = NULL;

	glGetShaderiv(shaderObject,
		GL_COMPILE_STATUS,
		&iShaderCompilationStatus);

	if (iShaderCompilationStatus == GL_FALSE)
	{
		glGetShaderiv(shaderObject,
			GL_INFO_LOG_LENGTH,
			&iInfoLength);
		if (iInfoLength > 0)
		{
			szInfoLog = (GLchar *)malloc(iInfoLength);

			if (szInfoLog != NULL)
			{
				GLsizei writtened;

				glGetShaderInfoLog(shaderObject,
					iInfoLength,
					&writtened,
					szInfoLog);
				
				fprintf(gpfile, "ERROR:SHADER:%s", szInfoLog);
				free(szInfoLog);
				uninitialize();
				//DestroyWindow(ghwnd);
				exit(0);
			}
		}
	}
}

//Checking the linking error for the shader program object
void checkShaderProgramLinkError(GLuint shaderProgramObject)
{
	GLint iShaderLinkStatus = 0;
	GLint iInfoLength = 0;
	GLchar *szInfoLog = NULL;

	glGetProgramiv(shaderProgramObject,
		GL_LINK_STATUS,
		&iShaderLinkStatus);

	if (iShaderLinkStatus == GL_FALSE)
	{
		glGetProgramiv(shaderProgramObject,
			GL_INFO_LOG_LENGTH,
			&iInfoLength);
		if (iInfoLength > 0)
		{
			szInfoLog = (GLchar *)malloc(iInfoLength);

			if (szInfoLog != NULL)
			{
				GLsizei wr;

				glGetShaderInfoLog(shaderProgramObject,
					iInfoLength,
					&wr,
					szInfoLog);

				fprintf(gpfile, "ERROR:SHADER LINK:%s", szInfoLog);
				free(szInfoLog);
				uninitialize();
				//DestroyWindow(ghwnd);
				exit(0);
			}

		}
	}
}

//Initialize all sphere shaders 
void initSphere()
{
	const GLchar* vertexShaderSourceCodeSphere =
		"#version 430 core" \
		"\n" \
		"in vec4 vPosition;" \
		"in vec3 vNormal;" \
		"uniform mat4 u_model_matrix;" \
		"uniform mat4 u_view_matrix;" \
		"uniform mat4 u_projection_matrix;" \
		"uniform int islkeypressed;" \
		"uniform vec4 u_light_position;" \
		"out vec3 tnorm;" \
		"out vec3 light_direction;" \
		"out vec3 viewer_vector;" \
		"void main(void)" \
		"{" \
		"if(islkeypressed == 1)" \
		"{" \
		"vec4 eye_coordinates = u_view_matrix *  u_model_matrix  * vPosition;" \
		"tnorm = mat3(u_view_matrix * u_model_matrix) * vNormal;" \
		"light_direction = vec3(u_light_position - eye_coordinates);" \
		"viewer_vector = vec3(-eye_coordinates.xyz);" \
		"}" \
		"gl_Position = u_projection_matrix * u_view_matrix * u_model_matrix * vPosition;" \
		" } ";

	gVertexShaderObject_Sphere = glCreateShader(GL_VERTEX_SHADER);

	compileShaderProgram(vertexShaderSourceCodeSphere, gVertexShaderObject_Sphere);

	//fragment
	const GLchar * fragmentShaderSourceCodeSphere =
		"#version 430 core" \
		"\n" \
		"out vec4 fragColor;" \
		"uniform int islkeypressed;" \
		"uniform vec3 u_la;" \
		"uniform vec3 u_ld;" \
		"uniform vec3 u_ls;" \
		"uniform vec3 u_ka;" \
		"uniform vec3 u_kd;" \
		"uniform vec3 u_ks;" \
		"in vec3 tnorm;" \
		"in vec3 light_direction;" \
		"in vec3 viewer_vector;" \
		"uniform float u_shininess;" \
		"void main(void)" \
		"{" \
		"if(islkeypressed == 1)" \
		"{" \
			"vec3 tnorm_normalized = normalize(tnorm);" \
			"vec3 light_direction_normalized = normalize(light_direction);" \
			"vec3 viewer_vector_normalized = normalize(viewer_vector);" \
			"float tn_dot_ldirection = max(dot(light_direction_normalized, tnorm_normalized), 0);" \
			"vec3 reflection_vector = reflect(-light_direction_normalized, tnorm_normalized);" \
			"vec3 ambient = u_la * u_ka;" \
			"vec3 difuse = u_ld * u_kd * tn_dot_ldirection;" \
			"vec3 specular = u_ls * u_ks * pow(max(dot(reflection_vector,viewer_vector_normalized),0),u_shininess);" \
			"vec3 phong_light_pf = ambient + difuse + specular;" \
			"fragColor = vec4(phong_light_pf, 1.0);" \
			"}" \
			"else" \
			"{" \
				"fragColor = vec4(1.0, 1.0 , 1.0 , 1.0);" \
		"}" \
		"}";

	gFragmentShaderObject_Sphere = glCreateShader(GL_FRAGMENT_SHADER);

	compileShaderProgram(fragmentShaderSourceCodeSphere, gFragmentShaderObject_Sphere);
	//Create shader program object
	gShaderProgramObject_Sphere = glCreateProgram();



	//Attach vertex,fragment shader program
	glAttachShader(gShaderProgramObject_Sphere, gVertexShaderObject_Sphere);
	glAttachShader(gShaderProgramObject_Sphere, gFragmentShaderObject_Sphere);


	//*** PRELINKING BINDING TO VERTEX ATTRIBUTES***
	glBindAttribLocation(gShaderProgramObject_Sphere,
		AMC_ATTRIBUTES_POSITION,
		"vPosition");

	glBindAttribLocation(gShaderProgramObject_Sphere,
		AMC_ATTRIBUTES_NORMAL,
		"vNormal");
	//link above shader program
	glLinkProgram(gShaderProgramObject_Sphere);

	// ***ERROR CHECKING LINKING********

	checkShaderProgramLinkError(gShaderProgramObject_Sphere);

	//Get uniforms location
	//sphere 
	getSphereVertexData(sphere_vertices, sphere_normals, sphere_textures, sphere_elements);
	gNumVertices = getNumberOfSphereVertices();
	gNumElements = getNumberOfSphereElements();


	////VAO AND VBO
	glGenVertexArrays(1, &vao_sphere);

	glBindVertexArray(vao_sphere);

	//position
	glGenBuffers(1, &vbo_position_vbo);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_position_vbo);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(sphere_vertices),
		sphere_vertices,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_POSITION,
		3,
		GL_FLOAT,
		GL_FALSE,
		0,
		NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_POSITION);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	//normal 

	glGenBuffers(1, &vbo_normals_vbo);

	glBindBuffer(GL_ARRAY_BUFFER, vbo_normals_vbo);

	glBufferData(GL_ARRAY_BUFFER,
		sizeof(sphere_normals),
		sphere_normals,
		GL_STATIC_DRAW);

	glVertexAttribPointer(AMC_ATTRIBUTES_NORMAL,
		3,
		GL_FLOAT,
		GL_FALSE,
		0,
		NULL);

	glEnableVertexAttribArray(AMC_ATTRIBUTES_NORMAL);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// element vbo
	glGenBuffers(1, &vbo_element_vbo);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo_element_vbo);

	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sphere_elements), sphere_elements, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	//unbind vao
	glBindVertexArray(0);
}

//Sphere drawing function
void drawSphere()
{
	glUseProgram(gShaderProgramObject_Sphere);


	mat4 modelMatrix;
	mat4 viewMatrix;
	mat4 modelViewProjectionMatrix;
	mat4 rotationMatrix;
	mat4 scaleMatrix;

	modelMatrix = mat4::identity();
	viewMatrix = mat4::identity();
	scaleMatrix = mat4::identity();
	rotationMatrix = mat4::identity();

	modelMatrix = translate(sphereX, sphereY, sphereZ);

	scaleMatrix = scale(0.5f, 0.5f, 0.5f);

	modelMatrix = modelMatrix * scaleMatrix;

	//

	if (isLighting)
	{
		glUniform1i(glGetUniformLocation(gShaderProgramObject_Sphere, "islkeypressed"), 1);

		glUniform1f(glGetUniformLocation(gShaderProgramObject_Sphere, "u_shininess"), materialShininess);

		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_la"), 1, lightAmbient);
		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_ld"), 1, lightDifuse);
		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_ls"), 1, lightSpecular);

		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_ka"), 1, materialAmbient);
		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_kd"), 1, materialDifuse);
		glUniform3fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_ks"), 1, materialSpecular);

		glUniform4fv(glGetUniformLocation(gShaderProgramObject_Sphere, "light_direction"), 1, lightPosition);
	}
	else
	{
		glUniform1i(glGetUniformLocation(gShaderProgramObject_Sphere, "islkeypressed"), 0);
	}

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_model_matrix"),
		1,
		GL_FALSE,
		modelMatrix);

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_view_matrix"),
		1,
		GL_FALSE,
		camera.GetViewMatrix());

	glUniformMatrix4fv(glGetUniformLocation(gShaderProgramObject_Sphere, "u_projection_matrix"),
		1,
		GL_FALSE,
		perspectiveProjectionMatrix);


	//END
	glBindVertexArray(vao_sphere);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbo_element_vbo);
	glDrawElements(GL_TRIANGLES, gNumElements, GL_UNSIGNED_SHORT, 0);

	glBindVertexArray(0);

	glBindTexture(GL_TEXTURE_2D, 0);

	glUseProgram(0);
}

