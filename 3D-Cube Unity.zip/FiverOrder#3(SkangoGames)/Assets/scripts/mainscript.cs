﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mainscript : MonoBehaviour {
	public GameObject objecttomove;
	public float speed;
	public float calculatedspeed,bounce;
	Vector3 lastposition = Vector3.zero;
	public List<Material> matlist = new List<Material>{};
	float[] sizearr = {0.1f,0.2f,0.3f,0.4f,0.5f,0.6f,0.7f,0.9f,1f};
	
	private void Start()
	{
		//this is array of possible sizes
		float size = sizearr[Random.Range(0,sizearr.Length)];
		//than we choose it from random ranges and set its size to choosed one
		gameObject.transform.localScale = new Vector3(size,size,size);
		//here we select random color 
		gameObject.GetComponent<MeshRenderer>().material = matlist[Random.Range(0,matlist.Count)];
		//here we randomly choose between this numbers how to  move our object
		float[] arrfloat = {0.1f,0.2f};
		//we get rigidbody
			Rigidbody gravity = objecttomove.GetComponent<Rigidbody>();
			//and then we add force to it to move with direction we choosed multiplyed by speed and time deltatime to move it smoothly
			gravity.AddForce(new Vector3(arrfloat[Random.Range(0,arrfloat.Length)],arrfloat[Random.Range(0,arrfloat.Length)],arrfloat[Random.Range(0,arrfloat.Length)]) * speed * Time.deltaTime);
	}
	

	private void FixedUpdate()
	{
		//just ignore this here i calculate some speeds for developing you can remove this later
		calculatedspeed = (objecttomove.transform.position - lastposition).magnitude;
		lastposition = objecttomove.transform.position;
	}

	private void OnCollisionEnter(Collision other)
	{
		//this void will call when cube hits somethung
		Rigidbody gravity = objecttomove.GetComponent<Rigidbody>();
		//we are setting its velocity to zero because if we do not do this we will be faster and faster when we hit.
		gravity.velocity = Vector3.zero;
		//ignore this too
		Debug.Log(other.contacts[0].normal + "this is normal");
		//here we are adding bounce back force to object dephending how it hits it
		gravity.AddForce(other.contacts[0].normal * bounce);
		//this is nothing too ignore
		Invoke("stopbounce",0.3f);
		//here we check if it hits central sphere it will change its color randomly.
		if (other.transform.CompareTag("sphere"))
		{
			gameObject.GetComponent<MeshRenderer>().material = matlist[Random.Range(0,matlist.Count)];
		}
		
	}

	void stopbounce () 
	{
		Debug.Log("called");
	}
}
