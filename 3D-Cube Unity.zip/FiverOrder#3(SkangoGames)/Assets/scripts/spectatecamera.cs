﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SkangoGames;
using System;
using System.Linq;
using System.Text;

namespace SkangoGames {
public class spectatecamera : MonoBehaviour {
	public GameObject sphere,cube,point;

		/// <summary>
		/// A simple free camera to be added to a Unity game object.
		/// 
		/// Keys:
		///	wasd / arrows	- movement
		///	q/e 			- up/down (local space)
		///	r/f 			- up/down (world space)
		///	pageup/pagedown	- up/down (world space)
		///	hold shift		- enable fast movement mode
		///	right mouse  	- enable free look
		///	mouse			- free look / rotation
		///     
		/// </summary>


			/// <summary>
			/// Normal speed of camera movement.
			/// </summary>
			public float movementSpeed = 10f;

			/// <summary>
			/// Speed of camera movement when shift is held down,
			/// </summary>
			public float fastMovementSpeed = 100f;

			/// <summary>
			/// Sensitivity for free look.
			/// </summary>
			public float freeLookSensitivity = 3f;

			/// <summary>
			/// Amount to zoom the camera when using the mouse wheel.
			/// </summary>
			public float zoomSensitivity = 10f;

			/// <summary>
			/// Amount to zoom the camera when using the mouse wheel (fast mode).
			/// </summary>
			public float fastZoomSensitivity = 50f;

			/// <summary>
			/// Set to true when free looking (on right mouse button).
			/// </summary>
			private bool looking = false;

			void Update()
			{
				//when we press space our cubes will spawn in spawnpoint
				if (Input.GetKeyDown(KeyCode.Space))
				{
					Instantiate(cube,point.transform.position,Quaternion.identity);
				}
				//when we press + sphere will move forward in z axes

				if (Input.GetKeyDown(KeyCode.KeypadPlus))
				{
					sphere.transform.position += new Vector3(0f,0f,1f);
				}
				//same but backwards

				if (Input.GetKeyDown(KeyCode.KeypadMinus))
				{
					sphere.transform.position += new Vector3(0f,0f,-1f);
				}
				//here when we prass right arrow key we move forward in x axes

				if (Input.GetKeyDown(KeyCode.RightArrow))
				{
					sphere.transform.position += new Vector3(1f,0f,0f);
				}
				//same but backwards

				if (Input.GetKeyDown(KeyCode.LeftArrow))
				{
					sphere.transform.position += new Vector3(-1f,0f,0f);
				}
				//same but in y axes

				if (Input.GetKeyDown(KeyCode.UpArrow))
				{
					sphere.transform.position += new Vector3(0f,1f,0f);
				}
				//again but backwards (down)

				if (Input.GetKeyDown(KeyCode.DownArrow))
				{
					sphere.transform.position += new Vector3(0f,-1f,0f);
				}

				//whay you see down here is just simple code that every unity developer will understand, simple player controller
				var fastMode = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
				var movementSpeed = fastMode ? this.fastMovementSpeed : this.movementSpeed;

				if (Input.GetKey(KeyCode.A))
				{
					transform.position = transform.position + (-transform.right * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.D))
				{
					transform.position = transform.position + (transform.right * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.W))
				{
					transform.position = transform.position + (transform.forward * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.S))
				{
					transform.position = transform.position + (-transform.forward * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.Q))
				{
					transform.position = transform.position + (transform.up * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.E))
				{
					transform.position = transform.position + (-transform.up * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.R) || Input.GetKey(KeyCode.PageUp))
				{
					transform.position = transform.position + (Vector3.up * movementSpeed * Time.deltaTime);
				}

				if (Input.GetKey(KeyCode.F) || Input.GetKey(KeyCode.PageDown))
				{
					transform.position = transform.position + (-Vector3.up * movementSpeed * Time.deltaTime);
				}
				//this is just mouse looking when we hold right mouse we can lookaround

				if (looking)
				{
					float newRotationX = transform.localEulerAngles.y + Input.GetAxis("Mouse X") * freeLookSensitivity;
					float newRotationY = transform.localEulerAngles.x - Input.GetAxis("Mouse Y") * freeLookSensitivity;
					transform.localEulerAngles = new Vector3(newRotationY, newRotationX, 0f);
				}

				float axis = Input.GetAxis("Mouse ScrollWheel");
				if (axis != 0)
				{
					var zoomSensitivity = fastMode ? this.fastZoomSensitivity : this.zoomSensitivity;
					transform.position = transform.position + transform.forward * axis * zoomSensitivity;
				}

				if (Input.GetKeyDown(KeyCode.Mouse1))
				{
					StartLooking();
				}
				else if (Input.GetKeyUp(KeyCode.Mouse1))
				{
					StopLooking();
				}
			}

			void OnDisable()
			{
				StopLooking();
			}

			/// <summary>
			/// Enable free looking.
			/// </summary>
			public void StartLooking()
			{
				looking = true;
				Cursor.visible = false;
				Cursor.lockState = CursorLockMode.Locked;
			}

			/// <summary>
			/// Disable free looking.
			/// </summary>
			public void StopLooking()
			{
				looking = false;
				Cursor.visible = true;
				Cursor.lockState = CursorLockMode.None;
			}
		
 }
}